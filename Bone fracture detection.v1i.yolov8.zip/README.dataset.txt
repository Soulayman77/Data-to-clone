# Bone fracture detection > 2023-03-05 5:51pm
https://universe.roboflow.com/fracture-uofxm/bone-fracture-detection-ivsy6

Provided by a Roboflow user
License: CC BY 4.0

